#import openpyxl
import Virpyt
from Virpyt import VirpytWorkbook
    


if __name__ == '__main__':
    #workbookname = input(print("Input workbookname: "))

    wb = VirpytWorkbook('us-500.csv')
    print(wb)        #address of openpyxl workbook object
    print(wb.sheets)        #list of sheet object addresses
    print(wb.sheetnames)    #list of names of worksheets

    for sheet in wb.sheets:     #prints each sheet title
        print("Found sheet named %s" % sheet.name)
        for table in sheet.tables:
            print("Found table: ", table.coords,
                  table._numcol, table._numrow)
            print(table.header)
