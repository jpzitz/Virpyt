import openpyxl

class Book():
    def __init__(self, file):
        self.file = openpyxl.load_workbook(file)

    @property
    def worksheets(self):
        return self.file.worksheets

    

wb = Book('sample.xlsx')
print(wb.file)
print(wb.worksheets)    #list of sheetnames
ws = wb.worksheets[wb.worksheets.index('<Worksheet "Sheet1">')]
print(ws)


# openpyxl shows spreadsheets as tuples of cells in each row
# then tuples of rows in each sheet
# I want to try to figure out how to grab a cell's location in the sheet
# by accessing its row value and index in that row tuple


# maybe turning the set of rows into a dict of cells
row_vals = []
for line in ws.values:
    row_vals.append(line)
    print(line)


mincol = 0
minrow = 0
for col in ws.iter_cols():
    mincol +=1
    minrow_incol = 0
    for row in col:
        minrow_incol +=1
        if (minrow_incol >= minrow):
            minrow = minrow_incol

print(mincol, minrow)
print(ws.calculate_dimension())




    

    
            
        
        

