#VirPyT test-03
#trying to jsut make everything work first before putting in classes


#import openpyxl
#from openpyxl import Workbook
import VirPyT
from VirPyT import Workbook, Sheet


worksheet = VirPyT.Sheet('sample.xlsx')
workbook = VirPyT.Workbook('sample.xlsx')





'''

wb = openpyxl.load_workbook('sample.xlsx') #filename = input("Input filename: "))

sheetnames = []

ws = openpyxl.worksheet
if ws:
    print("ok!")
    print(ws.title)

for sheet in wb.sheetnames:
    sheetnames.append(sheet.title())
    print("Found sheet named %s" %sheet.title())


print("sheet names: ", sheetnames)

    
    
    #for table in sheet.tables:
     #   print("Found table named %t" %table.title)

     #   for column_header in table.header:  # iterate through cells that make
                                            # up the header
      #     print(“col header is %s” % column_header.value)
       # for row in table:
        #    cell = row['<col name>']        # we want to be able to access a
                                            # cell according to the header name.
         #   print('row info is %s' % cell.value)



'''
