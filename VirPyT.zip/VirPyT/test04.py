import openpyxl

class Book():
    def __init__(self, file):
        self.file = openpyxl.load_workbook(file)

    @property
    def worksheets(self):
        return self.file.worksheets

wb = Book('sample.xlsx')
print(wb.file.worksheets)    #list of sheetnames


print(wb.worksheets)



